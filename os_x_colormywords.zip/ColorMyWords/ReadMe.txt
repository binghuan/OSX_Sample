
ColorMyWords

ColorMyWords is a simple text editing app that uses JavaScriptCore.framework to provide color highlighting for the words that are typed in the NSTextView.

The app uses basic techniques provided by the Objective-C API to JavaScriptcore for evaluating JavaScript scripts, creating and accessing JavaScript values, and correctly managing persistent references to JavaScript values.
